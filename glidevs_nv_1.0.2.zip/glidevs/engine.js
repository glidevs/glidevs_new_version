function rttA(){
    var mainBox = document.getElementById("mainBox");
    var floaterContA = document.getElementById("floaterContA");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(90deg)";
    floaterContA.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContA.style.transform = "rotatex(1deg)";
}
function rttB(){
    var mainBox = document.getElementById("mainBox");
    var floaterContB = document.getElementById("floaterContB");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(90deg)";
    floaterContB.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContB.style.transform = "rotatex(1deg)";
}
function rttC(){
    var mainBox = document.getElementById("mainBox");
    var floaterContC = document.getElementById("floaterContC");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(90deg)";
    floaterContC.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContC.style.transform = "rotatex(1deg)";
}
function rttD(){
    var mainBox = document.getElementById("mainBox");
    var floaterContD = document.getElementById("floaterContD");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(90deg)";
    floaterContD.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContD.style.transform = "rotatex(1deg)";
}
function rttE(){
    var mainBox = document.getElementById("mainBox");
    var floaterContE = document.getElementById("floaterContE");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(90deg)";
    floaterContE.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContE.style.transform = "rotatex(1deg)";
}


/*CLOSEBOXES */
function closeBoxA(){
    var mainBox = document.getElementById("mainBox");
    var floaterContA = document.getElementById("floaterContA");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(360deg)";
    floaterContA.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContA.style.transform = "rotatex(90deg)";
}

function closeBoxB(){
    var mainBox = document.getElementById("mainBox");
    var floaterContA = document.getElementById("floaterContB");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(360deg)";
    floaterContB.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContB.style.transform = "rotatex(90deg)";
}
function closeBoxC(){
    var mainBox = document.getElementById("mainBox");
    var floaterContC = document.getElementById("floaterContC");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(360deg)";
    floaterContC.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContC.style.transform = "rotatex(90deg)";
}
function closeBoxD(){
    var mainBox = document.getElementById("mainBox");
    var floaterContD = document.getElementById("floaterContD");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(360deg)";
    floaterContD.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContD.style.transform = "rotatex(90deg)";
}
function closeBoxE(){
    var mainBox = document.getElementById("mainBox");
    var floaterContE = document.getElementById("floaterContE");
    mainBox.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    mainBox.style.transform = "rotateY(360deg)";
    floaterContE.style.transition = "transform 2s"; // Agrega una transición de 2 segundos
    floaterContE.style.transform = "rotatex(90deg)";
}




